
# React Event Management Platform

## Features
- Browse Events
- Register for Events
- Create Events
- Manage Participants

## Run Project

### Install Dependencies
npm install

### Start React App
npm start
