
import React, { useState } from "react";

function App() {
  const [events, setEvents] = useState([
    {
      id: 1,
      title: "Tech Conference",
      date: "2026-05-15",
      description: "Technology Event",
      participants: []
    },
    {
      id: 2,
      title: "Music Festival",
      date: "2026-06-10",
      description: "Music and Fun",
      participants: []
    }
  ]);

  const [user, setUser] = useState("");
  const [newEvent, setNewEvent] = useState({
    title: "",
    date: "",
    description: ""
  });

  const registerEvent = (id) => {
    if (!user) {
      alert("Enter username first");
      return;
    }

    setEvents(events.map(event => {
      if (event.id === id && !event.participants.includes(user)) {
        return {
          ...event,
          participants: [...event.participants, user]
        };
      }
      return event;
    }));
  };

  const createEvent = () => {
    if (!newEvent.title || !newEvent.date) {
      alert("Fill all fields");
      return;
    }

    setEvents([
      ...events,
      {
        id: events.length + 1,
        ...newEvent,
        participants: []
      }
    ]);

    setNewEvent({
      title: "",
      date: "",
      description: ""
    });
  };

  return (
    <div className="container">
      <h1>Event Management Platform</h1>

      <div className="card">
        <h2>User Login</h2>
        <input
          type="text"
          placeholder="Enter Username"
          value={user}
          onChange={(e) => setUser(e.target.value)}
        />
      </div>

      <div className="card">
        <h2>Create Event (Organizer)</h2>

        <input
          type="text"
          placeholder="Event Title"
          value={newEvent.title}
          onChange={(e) =>
            setNewEvent({ ...newEvent, title: e.target.value })
          }
        />

        <input
          type="date"
          value={newEvent.date}
          onChange={(e) =>
            setNewEvent({ ...newEvent, date: e.target.value })
          }
        />

        <textarea
          placeholder="Description"
          value={newEvent.description}
          onChange={(e) =>
            setNewEvent({ ...newEvent, description: e.target.value })
          }
        ></textarea>

        <button onClick={createEvent}>Create Event</button>
      </div>

      <h2>Available Events</h2>

      {events.map((event) => (
        <div className="card" key={event.id}>
          <h3>{event.title}</h3>
          <p>{event.description}</p>
          <p>Date: {event.date}</p>

          <button onClick={() => registerEvent(event.id)}>
            Register
          </button>

          <h4>Participants:</h4>
          <ul>
            {event.participants.map((p, index) => (
              <li key={index}>{p}</li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
}

export default App;
